@php
    $currentLocale = app()->getLocale();
    $isRtl = in_array($currentLocale, ['ur', 'ar']);
    $localesList = [
        'en' => ['name' => 'English', 'native' => 'English', 'flag' => '🇺🇸'],
        'ur' => ['name' => 'Urdu', 'native' => 'اردو', 'flag' => '🇵🇰'],
        'hi' => ['name' => 'Hindi', 'native' => 'हिन्दी', 'flag' => '🇮🇳'],
        'tr' => ['name' => 'Turkish', 'native' => 'Türkçe', 'flag' => '🇹🇷'],
        'ar' => ['name' => 'Arabic', 'native' => 'العربية', 'flag' => '🇦🇪'],
        'es' => ['name' => 'Spanish', 'native' => 'Español', 'flag' => '🇪🇸'],
        'fr' => ['name' => 'French', 'native' => 'Français', 'flag' => '🇫🇷'],
        'de' => ['name' => 'German', 'native' => 'Deutsch', 'flag' => '🇩🇪'],
    ];
    $workspace = auth()->check() ? auth()->user()->workspace : null;
    $customLogo = \App\Models\CmsContent::getSystemLogo();
    $faviconUrl = \App\Models\CmsContent::getFaviconUrl();
    $brandName = \App\Models\CmsContent::getVal('website_brand_name', 'Invoicy');
    $brandSub = \App\Models\CmsContent::getVal('website_brand_sub', 'RedMaple');
@endphp
<!DOCTYPE html>
<html lang="{{ $currentLocale }}" dir="{{ $isRtl ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title ?? "$brandName by $brandSub" }} - Commercial SaaS Invoicing</title>
    <!-- Dynamic Favicon -->
    @if($faviconUrl)
        <link rel="icon" href="{{ $faviconUrl }}">
    @else
        <link rel="icon" type="image/svg+xml" href="{{ asset('images/maple-leaf.svg') }}">
    @endif
    <!-- Tailwind CSS CDN for zero-build Hostinger deployment -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: {
                            50: '#fef2f2',
                            100: '#fee2e2',
                            200: '#fecaca',
                            500: '#ef4444',
                            600: '#dc2626',
                            700: '#b91c1c',
                            800: '#991b1b',
                            900: '#7f1d1d',
                        }
                    }
                }
            }
        }
    </script>
    <!-- Phosphor Icons CDN -->
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/@phosphor-icons/web@2.1.1/src/bold/style.css"/>
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/@phosphor-icons/web@2.1.1/src/regular/style.css"/>
    <style>
        [dir="rtl"] { text-align: right; }
        [dir="rtl"] .ltr-text { direction: ltr; text-align: left; }
    </style>
    @livewireStyles
</head>
<body class="bg-slate-50 text-slate-800 font-sans antialiased">
    <!-- Persistent Assisted Session / Impersonation Banner (Section 11) -->
    @if(session('super_admin_assisted_session'))
    <div class="bg-gradient-to-r from-amber-600 via-rose-600 to-amber-700 text-white px-4 py-2 text-xs font-bold flex items-center justify-between shadow-lg sticky top-0 z-50">
        <div class="flex items-center gap-2">
            <span class="animate-pulse bg-white text-rose-700 px-2 py-0.5 rounded text-[10px] uppercase font-black tracking-wider">
                Privileged Support Mode
            </span>
            <span>
                Assisted Session Active: Viewing workspace <strong>{{ session('assisted_workspace_name') }}</strong> (Operator: {{ session('assisted_operator_email') }})
            </span>
        </div>
        <form method="POST" action="{{ route('admin.impersonate.stop') }}" class="inline">
            @csrf
            <button type="submit" class="px-3 py-1 bg-white hover:bg-slate-100 text-slate-900 rounded font-bold transition flex items-center gap-1 shadow-xs">
                <i class="ph ph-sign-out font-bold"></i> Exit Assisted Session
            </button>
        </form>
    </div>
    @endif
    <div class="min-h-screen flex" x-data="{ sidebarCollapsed: localStorage.getItem('sidebar_collapsed') === 'true' }">
        <!-- Sidebar Navigation (Expand/Collapse Supported) -->
        <aside :class="sidebarCollapsed ? 'w-20' : 'w-72'" class="bg-slate-900 text-slate-200 flex flex-col shrink-0 transition-all duration-300 relative">
            <!-- Brand Header -->
            <div class="h-16 flex items-center border-b border-slate-800 transition-all duration-300 overflow-hidden"
                 :class="sidebarCollapsed ? 'justify-center px-2' : 'justify-between px-4 gap-2'">
                <div class="flex items-center gap-3 overflow-hidden" :class="sidebarCollapsed ? 'justify-center' : ''">
                    @if($customLogo)
                        <div class="h-10 flex items-center shrink-0 cursor-pointer"
                             @click="if(sidebarCollapsed) { sidebarCollapsed = false; localStorage.setItem('sidebar_collapsed', false); }"
                             :title="sidebarCollapsed ? 'Click to expand sidebar' : ''">
                            <img src="{{ $customLogo }}" alt="{{ $brandName }}" class="max-h-9 max-w-[130px] object-contain rounded-lg">
                        </div>
                    @else
                        <div class="w-10 h-10 rounded-xl bg-red-600/10 border border-red-500/20 flex items-center justify-center p-1.5 shrink-0 shadow-sm overflow-hidden cursor-pointer hover:bg-red-600/20 transition"
                             @click="if(sidebarCollapsed) { sidebarCollapsed = false; localStorage.setItem('sidebar_collapsed', false); }"
                             :title="sidebarCollapsed ? 'Click to expand sidebar' : ''">
                            <!-- Red Maple Leaf Vector -->
                            <svg class="w-full h-full text-red-600 drop-shadow-sm" viewBox="0 0 900 900" fill="currentColor">
                                <path d="M450 50 L562 278 L732 232 L640 394 L850 472 L670 612 L760 800 L546 728 L490 880 L410 880 L354 728 L140 800 L230 612 L50 472 L260 394 L168 232 L338 278 Z" />
                            </svg>
                        </div>
                    @endif
                    <div x-show="!sidebarCollapsed" x-transition.opacity.duration.200ms class="whitespace-nowrap min-w-0">
                        <h1 class="font-black text-white text-sm tracking-tight flex items-center gap-1">
                            {{ $brandName }} <span class="text-xs font-normal text-slate-400">by</span> <span class="text-red-500 font-bold">{{ $brandSub }}</span>
                        </h1>
                        <p class="text-[10px] uppercase font-bold tracking-wider text-slate-400">SaaS Suite</p>
                    </div>
                </div>

                <!-- Sidebar Collapse / Expand Toggle Button -->
                <button x-show="!sidebarCollapsed"
                        @click="sidebarCollapsed = !sidebarCollapsed; localStorage.setItem('sidebar_collapsed', sidebarCollapsed)"
                        type="button"
                        class="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition shrink-0"
                        title="Collapse Sidebar">
                    <i class="ph ph-caret-left text-base font-bold"></i>
                </button>
            </div>

            <!-- Nav Links -->
            <nav class="flex-1 px-3 py-5 space-y-1 overflow-y-auto">
                @if(auth()->user() && auth()->user()->isSuperAdmin())
                    <!-- Super Admin Control Centre Link (CP) -->
                    <div class="px-3 pb-1 pt-1">
                        <span x-show="!sidebarCollapsed" class="text-[10px] font-extrabold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                            <i class="ph ph-shield-star text-xs"></i> Platform Control
                        </span>
                    </div>

                    <a href="{{ route('admin.dashboard') }}" 
                       :class="sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'gap-3 px-3 py-2'"
                       class="flex items-center rounded-lg text-sm font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500 hover:text-slate-950 transition shadow-sm"
                       :title="sidebarCollapsed ? 'Control Centre (CP)' : ''">
                        <i class="ph ph-shield-check text-lg shrink-0 text-amber-400"></i>
                        <span x-show="!sidebarCollapsed" class="truncate font-bold">Control Centre (CP)</span>
                    </a>

                    <div class="pt-3 pb-1 border-t border-slate-800/80 my-2">
                        <span x-show="!sidebarCollapsed" class="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-500">Agency Workspace</span>
                    </div>
                @endif

                <a href="{{ route('dashboard') }}" 
                   :class="sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'gap-3 px-3 py-2'"
                   class="flex items-center rounded-lg text-sm font-medium transition {{ request()->routeIs('dashboard') ? 'bg-red-600 text-white shadow-sm [&>i]:!text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"
                   :title="sidebarCollapsed ? '{{ __('Dashboard') }}' : ''">
                    <i class="ph ph-squares-four text-lg {{ request()->routeIs('dashboard') ? '!text-white' : '' }} shrink-0"></i>
                    <span x-show="!sidebarCollapsed" class="truncate">{{ __('Dashboard') }}</span>
                </a>

                <a href="{{ route('invoices.index') }}" 
                   :class="sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'gap-3 px-3 py-2'"
                   class="flex items-center rounded-lg text-sm font-medium transition {{ request()->routeIs('invoices.*') ? 'bg-red-600 text-white shadow-sm [&>i]:!text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"
                   :title="sidebarCollapsed ? '{{ __('Invoices') }}' : ''">
                    <i class="ph ph-receipt text-lg {{ request()->routeIs('invoices.*') ? '!text-white' : '' }} shrink-0"></i>
                    <span x-show="!sidebarCollapsed" class="truncate">{{ __('Invoices') }}</span>
                </a>

                <a href="{{ route('recurring.index') }}" 
                   :class="sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'gap-3 px-3 py-2'"
                   class="flex items-center rounded-lg text-sm font-medium transition {{ request()->routeIs('recurring.*') ? 'bg-red-600 text-white shadow-sm [&>i]:!text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"
                   :title="sidebarCollapsed ? '{{ __('Recurring Retainers') }}' : ''">
                    <i class="ph ph-arrows-clockwise text-lg {{ request()->routeIs('recurring.*') ? '!text-white' : 'text-cyan-400' }} shrink-0"></i>
                    <span x-show="!sidebarCollapsed" class="truncate">{{ __('Recurring Retainers') }}</span>
                </a>

                <a href="{{ route('credit-notes.index') }}" 
                   :class="sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'gap-3 px-3 py-2'"
                   class="flex items-center rounded-lg text-sm font-medium transition {{ request()->routeIs('credit-notes.*') ? 'bg-red-600 text-white shadow-sm [&>i]:!text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"
                   :title="sidebarCollapsed ? '{{ __('Credit Notes') }}' : ''">
                    <i class="ph ph-arrow-u-up-left text-lg {{ request()->routeIs('credit-notes.*') ? '!text-white' : 'text-rose-400' }} shrink-0"></i>
                    <span x-show="!sidebarCollapsed" class="truncate">{{ __('Credit Notes') }}</span>
                </a>

                <a href="{{ route('reminders.index') }}" 
                   :class="sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'gap-3 px-3 py-2'"
                   class="flex items-center rounded-lg text-sm font-medium transition {{ request()->routeIs('reminders.*') ? 'bg-red-600 text-white shadow-sm [&>i]:!text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"
                   :title="sidebarCollapsed ? '{{ __('Reminders & Scheduler') }}' : ''">
                    <i class="ph ph-bell-ringing text-lg {{ request()->routeIs('reminders.*') ? '!text-white' : 'text-amber-400' }} shrink-0"></i>
                    <span x-show="!sidebarCollapsed" class="truncate">{{ __('Reminders & Scheduler') }}</span>
                </a>

                <a href="{{ route('clients.index') }}" 
                   :class="sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'gap-3 px-3 py-2'"
                   class="flex items-center rounded-lg text-sm font-medium transition {{ request()->routeIs('clients.*') ? 'bg-red-600 text-white shadow-sm [&>i]:!text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"
                   :title="sidebarCollapsed ? '{{ __('Client CRM') }}' : ''">
                    <i class="ph ph-users text-lg {{ request()->routeIs('clients.*') ? '!text-white' : '' }} shrink-0"></i>
                    <span x-show="!sidebarCollapsed" class="truncate">{{ __('Client CRM') }}</span>
                </a>

                <a href="{{ route('services.index') }}" 
                   :class="sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'gap-3 px-3 py-2'"
                   class="flex items-center rounded-lg text-sm font-medium transition {{ request()->routeIs('services.*') ? 'bg-red-600 text-white shadow-sm [&>i]:!text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"
                   :title="sidebarCollapsed ? '{{ __('Catalog & Presets') }}' : ''">
                    <i class="ph ph-package text-lg {{ request()->routeIs('services.*') ? '!text-white' : '' }} shrink-0"></i>
                    <span x-show="!sidebarCollapsed" class="truncate">{{ __('Catalog & Presets') }}</span>
                </a>

                @if(!auth()->user() || (!auth()->user()->isSuperAdmin() && !auth()->user()->isStaff()))
                <a href="{{ route('membership.index') }}" 
                   :class="sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'gap-3 px-3 py-2'"
                   class="flex items-center rounded-lg text-sm font-medium transition {{ request()->routeIs('membership.*') ? 'bg-red-600 text-white shadow-sm [&>i]:!text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"
                   :title="sidebarCollapsed ? '{{ __('Plan & Billing') }}' : ''">
                    <i class="ph ph-crown text-lg {{ request()->routeIs('membership.*') ? '!text-white' : 'text-amber-400' }} shrink-0"></i>
                    <span x-show="!sidebarCollapsed" class="truncate">{{ __('Plan & Billing') }}</span>
                </a>
                @endif

                <a href="{{ route('docs.index') }}" target="_blank" 
                   :class="sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'gap-3 px-3 py-2'"
                   class="flex items-center rounded-lg text-sm font-medium text-slate-300 hover:bg-slate-800 hover:text-white transition"
                   :title="sidebarCollapsed ? '{{ __('Documentation') }}' : ''">
                    <i class="ph ph-book-open text-lg text-sky-400 shrink-0"></i>
                    <span x-show="!sidebarCollapsed" class="truncate">{{ __('Documentation') }}</span>
                </a>

                <a href="{{ route('help.index') }}" 
                   :class="sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'gap-3 px-3 py-2'"
                   class="flex items-center rounded-lg text-sm font-medium transition {{ request()->routeIs('help.*') ? 'bg-red-600 text-white shadow-sm [&>i]:!text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"
                   :title="sidebarCollapsed ? '{{ __('Help & Guide') }}' : ''">
                    <i class="ph ph-question text-lg {{ request()->routeIs('help.*') ? '!text-white' : 'text-emerald-400' }} shrink-0"></i>
                    <span x-show="!sidebarCollapsed" class="truncate">{{ __('Help & Guide') }}</span>
                </a>

                @if(!auth()->user() || !auth()->user()->isStaff())
                <a href="{{ route('settings.index') }}" 
                   :class="sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'gap-3 px-3 py-2'"
                   class="flex items-center rounded-lg text-sm font-medium transition {{ request()->routeIs('settings.*') ? 'bg-red-600 text-white shadow-sm [&>i]:!text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"
                   :title="sidebarCollapsed ? (auth()->user() && auth()->user()->isSuperAdmin() ? '{{ __('System Settings') }}' : '{{ __('Agency Settings') }}') : ''">
                    <i class="ph ph-gear text-lg {{ request()->routeIs('settings.*') ? '!text-white' : 'text-slate-400' }} shrink-0"></i>
                    <span x-show="!sidebarCollapsed" class="truncate">{{ (auth()->user() && auth()->user()->isSuperAdmin()) ? __('System Settings') : __('Agency Settings') }}</span>
                </a>
                @endif
            </nav>

            <!-- Advertisement Section on Left Sidebar (Item 2) -->
            @if(!auth()->user() || (!auth()->user()->isSuperAdmin() && !auth()->user()->isStaff()))
            @php
                $sidebarAd = null;
                try {
                    $sidebarAd = \App\Models\Advertisement::getActive('app_sidebar');
                } catch (\Throwable $e) {}
            @endphp
            <div class="px-3 py-2" x-show="!sidebarCollapsed" x-transition.opacity.duration.200ms>
                @if($sidebarAd)
                    @php
                        $adLink = route('ads.click', $sidebarAd->id);
                        $adTarget = $sidebarAd->open_in_new_tab ? '_blank' : '_self';
                    @endphp
                    @if($sidebarAd->type === 'image' && !empty($sidebarAd->image_path))
                        <div class="relative overflow-hidden rounded-xl border border-slate-700/80 shadow-xs group">
                            <a href="{{ $adLink }}" target="{{ $adTarget }}" class="block">
                                <img src="{{ $sidebarAd->image_path }}" alt="{{ $sidebarAd->alt_text ?? $sidebarAd->title }}" 
                                     class="w-full h-auto max-h-24 object-cover group-hover:scale-105 transition duration-300">
                            </a>
                        </div>
                    @elseif($sidebarAd->type === 'html' && !empty($sidebarAd->html_code))
                        <div class="overflow-hidden rounded-xl bg-slate-800 border border-slate-700 p-2 text-xs">
                            {!! $sidebarAd->html_code !!}
                        </div>
                    @else
                        @php $styles = $sidebarAd->getThemeStyles(); @endphp
                        <div class="relative overflow-hidden rounded-xl {{ $styles['card_bg'] }} p-3 text-white shadow-xs">
                            <div class="flex items-center justify-between mb-1">
                                <span class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded {{ $styles['badge'] }} font-bold text-[9px] uppercase tracking-wider">
                                    <i class="ph ph-sparkle text-amber-300"></i> {{ $sidebarAd->badge_text ?? 'PRO SUITE' }}
                                </span>
                                @if($sidebarAd->destination_url)
                                    <a href="{{ $adLink }}" target="{{ $adTarget }}" class="text-slate-400 hover:text-white text-[10px]" title="Learn More">
                                        <i class="ph ph-arrow-up-right text-xs"></i>
                                    </a>
                                @endif
                            </div>
                            <h5 class="font-bold text-xs text-white leading-tight">
                                {{ $sidebarAd->headline }}
                            </h5>
                            @if($sidebarAd->body_text)
                                <p class="text-[10px] text-slate-400 mt-1 leading-snug line-clamp-2">
                                    {{ $sidebarAd->body_text }}
                                </p>
                            @endif
                            <a href="{{ $adLink }}" target="{{ $adTarget }}" class="mt-2.5 w-full block text-center py-1.5 {{ $styles['btn'] }} font-bold text-[11px] rounded-lg transition shadow-2xs">
                                {{ $sidebarAd->cta_text ?? 'Learn More' }}
                            </a>
                        </div>
                    @endif
                @else
                    <div class="relative overflow-hidden rounded-xl bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700/80 p-3 text-white shadow-xs">
                        <div class="flex items-center justify-between mb-1">
                            <span class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-red-600/30 text-red-400 font-bold text-[9px] uppercase tracking-wider">
                                <i class="ph ph-sparkle text-amber-300"></i> PRO SUITE
                            </span>
                            <a href="https://redmapleagency.com" target="_blank" class="text-slate-400 hover:text-white text-[10px]" title="Visit RedMaple Studio">
                                <i class="ph ph-arrow-up-right text-xs"></i>
                            </a>
                        </div>
                        <h5 class="font-bold text-xs text-white leading-tight">
                            Grow with RedMaple Studio
                        </h5>
                        <p class="text-[10px] text-slate-400 mt-1 leading-snug">
                            Custom Apps, CRM & Dedicated Developer Pods for agencies.
                        </p>
                        <a href="{{ route('membership.index') }}" class="mt-2.5 w-full block text-center py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-[11px] rounded-lg transition shadow-2xs">
                            Upgrade & Save 20%
                        </a>
                    </div>
                @endif
            </div>

            <!-- Compact Icon Ad for Collapsed State -->
            <div class="px-3 py-2 flex justify-center" x-show="sidebarCollapsed" x-cloak>
                <a href="{{ $sidebarAd ? route('ads.click', $sidebarAd->id) : route('membership.index') }}" 
                   target="{{ ($sidebarAd && $sidebarAd->open_in_new_tab) ? '_blank' : '_self' }}"
                   class="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 to-rose-700 flex items-center justify-center text-white hover:scale-105 transition shadow-sm" 
                   title="{{ $sidebarAd ? $sidebarAd->headline : 'Upgrade to Pro & Special Offers' }}">
                    <i class="ph ph-crown text-lg text-amber-300"></i>
                </a>
            </div>
            @endif

            <!-- Bottom User Profile & Sign Out -->
            <div class="p-4 border-t border-slate-800">
                <div class="flex items-center justify-between" :class="sidebarCollapsed ? 'justify-center flex-col gap-2' : ''">
                    @if(auth()->user() && auth()->user()->isStaff())
                        <div class="flex items-center gap-2 overflow-hidden" title="Staff Account">
                            <div class="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold text-white shadow-sm shrink-0">
                                {{ substr(auth()->user()->name ?? 'U', 0, 1) }}
                            </div>
                            <div class="text-xs truncate" x-show="!sidebarCollapsed">
                                <p class="font-medium text-white truncate max-w-[100px]">{{ auth()->user()->name }}</p>
                                <p class="text-slate-400 capitalize text-[10px] flex items-center gap-1">
                                    <span class="text-emerald-400 font-semibold">Staff Member</span>
                                </p>
                            </div>
                        </div>
                    @else
                        <a href="{{ route('settings.index') }}#profile" class="flex items-center gap-2 overflow-hidden group hover:opacity-90 transition" title="Click to edit owner profile & contact name">
                            <div class="w-8 h-8 rounded-full bg-red-600 flex items-center justify-center text-xs font-bold text-white shadow-sm shrink-0 group-hover:scale-105 transition">
                                {{ substr(auth()->user()->name ?? 'U', 0, 1) }}
                            </div>
                            <div class="text-xs truncate" x-show="!sidebarCollapsed">
                                <p class="font-medium text-white truncate max-w-[100px] group-hover:text-red-300 transition">{{ auth()->user()->name }}</p>
                                <p class="text-slate-400 capitalize text-[10px] flex items-center gap-1">
                                    @if(auth()->user() && auth()->user()->isSuperAdmin())
                                        <span class="text-amber-400 font-bold flex items-center gap-1">
                                            <i class="ph ph-shield-check text-xs"></i> Super Admin
                                        </span>
                                    @else
                                        <span>{{ auth()->user()->role }}</span>
                                        <i class="ph ph-pencil-simple text-[10px] text-slate-500 group-hover:text-slate-300"></i>
                                    @endif
                                </p>
                            </div>
                        </a>
                    @endif
                    <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                       class="text-slate-400 hover:text-rose-400 p-1.5 transition cursor-pointer" title="{{ __('Sign Out') }}">
                        <i class="ph ph-sign-out text-lg"></i>
                    </a>
                    <form id="logout-form" method="POST" action="{{ route('logout') }}" class="hidden">
                        @csrf
                    </form>
                </div>
            </div>
        </aside>

        <!-- Main Content Area -->
        <main class="flex-1 flex flex-col overflow-y-auto">
            <!-- Top Header -->
            <header class="h-16 bg-white border-b border-slate-200 px-6 sm:px-8 flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <!-- Topbar Expand/Collapse Sidebar Toggle Button -->
                    <button @click="sidebarCollapsed = !sidebarCollapsed; localStorage.setItem('sidebar_collapsed', sidebarCollapsed)"
                            type="button"
                            class="p-2 rounded-xl border border-slate-200 text-slate-600 hover:text-red-600 hover:bg-slate-50 transition shadow-2xs"
                            title="Toggle Sidebar Expand / Collapse">
                        <i class="ph ph-sidebar-simple text-lg"></i>
                    </button>
                    <div class="flex items-center gap-2.5">
                        <h2 class="text-lg font-bold text-slate-800">{{ $header ?? __('Overview') }}</h2>
                        @if(auth()->user() && auth()->user()->isSuperAdmin())
                            <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300 shadow-2xs">
                                <i class="ph ph-shield-check text-sm font-bold text-amber-600"></i> Super Admin
                            </span>
                        @endif
                    </div>
                </div>
                <div class="flex items-center gap-3">
                    @if(auth()->user() && !auth()->user()->isSuperAdmin() && auth()->user()->workspace && auth()->user()->workspace->isTrial())
                        @php
                            $ws = auth()->user()->workspace;
                            $plan = $ws->currentSubscription?->plan;
                            $limit = ($plan && $plan->invoice_limit) ? $plan->invoice_limit : 15;
                            $used = $ws->invoices()->where('created_at', '>=', now()->startOfMonth())->count();
                            $available = max(0, $limit - $used);
                        @endphp
                        <div class="hidden sm:inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-900 text-xs shadow-2xs">
                            <span class="inline-block w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                            <span class="font-bold uppercase tracking-wider text-[10px] text-amber-700">{{ __('Trial Version') }}</span>
                            <span class="text-amber-300">|</span>
                            <span class="font-semibold text-slate-700 text-xs">
                                <span class="text-amber-800 font-bold">{{ $available }}</span> / {{ $limit }} {{ __('Invoices Available') }}
                            </span>
                            @if(!auth()->user()->isStaff())
                            <a href="{{ route('membership.index') }}" class="ml-1 px-2 py-0.5 rounded-md bg-amber-600 hover:bg-amber-700 text-white font-bold text-[10px] uppercase tracking-wide transition shadow-xs">
                                {{ __('Upgrade') }}
                            </a>
                            @endif
                        </div>
                    @endif
                    <!-- Topbar Language Switcher Dropdown -->
                    <div class="relative" x-data="{ open: false }">
                        <button @click="open = !open" type="button" class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-medium text-slate-700 transition">
                            <span>{{ $localesList[$currentLocale]['flag'] ?? '🌐' }}</span>
                            <span class="hidden sm:inline font-semibold">{{ $localesList[$currentLocale]['native'] ?? __('Language') }}</span>
                            <i class="ph ph-caret-down text-slate-400"></i>
                        </button>
                        <div x-show="open" @click.outside="open = false" x-cloak class="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50">
                            <div class="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">{{ __('Switch App Language') }}</div>
                            @foreach($localesList as $code => $data)
                                <a href="{{ route('locale.switch', $code) }}" class="flex items-center justify-between px-3 py-1.5 text-xs hover:bg-red-50 hover:text-red-700 transition {{ $currentLocale === $code ? 'bg-red-50 text-red-700 font-bold' : 'text-slate-700' }}">
                                    <span class="flex items-center gap-2">
                                        <span>{{ $data['flag'] }}</span>
                                        <span>{{ $data['name'] }}</span>
                                    </span>
                                    <span class="text-slate-400 text-[10px]">{{ $data['native'] }}</span>
                                </a>
                            @endforeach
                        </div>
                    </div>

                    <!-- Concurrency-Safe Ledger Lock Badge (Mockup) -->
                    <span class="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                        <i class="ph ph-shield-check text-emerald-600 text-sm"></i> Concurrency-Safe Ledger Lock
                    </span>

                    <!-- Documentation Quick Link -->
                    <a href="{{ route('docs.index') }}" target="_blank" class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition" title="{{ __('Documentation') }}">
                        <i class="ph ph-book-open text-sky-600 text-sm"></i>
                        <span class="hidden md:inline">{{ __('Documentation') }}</span>
                    </a>

                    <!-- Create Invoice Action -->
                    <a href="{{ route('invoices.create') }}" class="inline-flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-semibold rounded-lg shadow-sm transition">
                        <i class="ph ph-plus-circle text-base"></i>
                        {{ __('Create Invoice') }}
                    </a>
                </div>
            </header>

            <!-- Notifications & Alert Banners -->
            <div class="px-8 pt-4 space-y-3">
                @if(auth()->check() && !auth()->user()->isSuperAdmin() && !auth()->user()->isTrial() && !auth()->user()->workspace?->hasConfiguredSmtp() && !request()->routeIs('settings.*'))
                    <div class="p-4 rounded-xl bg-amber-50 border-2 border-amber-400 text-amber-950 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
                        <div class="flex items-center gap-3">
                            <div class="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center text-lg shrink-0 shadow-xs">
                                <i class="ph ph-warning-diamond"></i>
                            </div>
                            <div>
                                <span class="font-bold text-amber-950 block text-xs sm:text-sm">{{ __('Mandatory Action Required: Configure Outgoing SMTP Mail Server') }}</span>
                                <span class="text-amber-900 text-xs">{{ __('As a subscribed agency, you are required to configure your own authenticated Outgoing SMTP mail server before dispatching invoices to clients.') }}</span>
                            </div>
                        </div>
                        @if(!auth()->user()->isStaff())
                            <a href="{{ route('settings.index') }}#smtp" class="shrink-0 px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-lg transition shadow-xs flex items-center gap-1.5 whitespace-nowrap">
                                <i class="ph ph-gear"></i> {{ __('Configure SMTP Now') }}
                            </a>
                        @endif
                    </div>
                @endif

                @if(auth()->check() && !auth()->user()->hasVerifiedEmail() && !auth()->user()->is_super_admin)
                    <div class="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs">
                        <div class="flex items-center gap-2.5">
                            <i class="ph ph-envelope-simple-warning text-xl text-amber-600 shrink-0"></i>
                            <div>
                                <span class="font-bold text-amber-800">{{ __('Email Verification Required:') }}</span>
                                <span>{{ __('You must verify your account email address') }} (<span class="font-semibold text-slate-800">{{ auth()->user()->email }}</span>) {{ __('before dispatching invoices or payment reminders to clients.') }}</span>
                            </div>
                        </div>
                        <form method="POST" action="{{ route('verification.send') }}" class="shrink-0">
                            @csrf
                            <button type="submit" class="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-lg transition shadow-xs flex items-center gap-1.5">
                                <i class="ph ph-paper-plane-tilt"></i> {{ __('Resend Verification Email') }}
                            </button>
                        </form>
                    </div>
                @endif

                @if(session('success'))
                    <div class="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs sm:text-sm flex items-center gap-3 shadow-2xs">
                        <i class="ph ph-check-circle text-lg text-emerald-600 shrink-0"></i>
                        <span>{{ session('success') }}</span>
                    </div>
                @endif
                @if(session('warning'))
                    <div class="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs sm:text-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs">
                        <div class="flex items-center gap-3">
                            <i class="ph ph-warning-circle text-lg text-amber-600 shrink-0"></i>
                            <div>
                                <span class="font-bold text-amber-800">{{ __('Notice:') }}</span>
                                <span>{{ session('warning') }}</span>
                            </div>
                        </div>
                        @if(auth()->check() && !auth()->user()->hasVerifiedEmail() && !auth()->user()->is_super_admin)
                            <form method="POST" action="{{ route('verification.send') }}" class="shrink-0">
                                @csrf
                                <button type="submit" class="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-lg transition shadow-xs flex items-center gap-1.5">
                                    <i class="ph ph-paper-plane-tilt"></i> {{ __('Resend Email') }}
                                </button>
                            </form>
                        @endif
                    </div>
                @endif
                @if(session('message'))
                    <div class="p-4 rounded-xl bg-sky-50 border border-sky-200 text-sky-800 text-xs sm:text-sm flex items-center gap-3 shadow-2xs">
                        <i class="ph ph-info text-lg text-sky-600 shrink-0"></i>
                        <span>{{ session('message') }}</span>
                    </div>
                @endif
                @if(session('error'))
                    <div class="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs sm:text-sm flex items-center gap-3 shadow-2xs">
                        <i class="ph ph-warning-circle text-lg text-rose-600 shrink-0"></i>
                        <span>{{ session('error') }}</span>
                    </div>
                @endif
            </div>

            <!-- Page Body -->
            <div class="p-8">
                {{ $slot ?? '' }}
                @yield('content')
            </div>
        </main>
    </div>

    <!-- Auto-Signout on Browser / Tab Close (Security Policy) -->
    <script>
        (function() {
            let isInternalNavigation = false;

            // Mark internal navigation on any user interaction inside the document
            document.addEventListener('pointerdown', function() { isInternalNavigation = true; }, true);
            document.addEventListener('click', function() { isInternalNavigation = true; }, true);
            document.addEventListener('submit', function() { isInternalNavigation = true; }, true);
            document.addEventListener('keydown', function() { isInternalNavigation = true; }, true);
            window.addEventListener('popstate', function() { isInternalNavigation = true; });
            document.addEventListener('livewire:navigating', function() { isInternalNavigation = true; });

            // Reset flag when page finishes rendering in the current tab
            window.addEventListener('pageshow', function() {
                isInternalNavigation = false;
            });

            // Dispatches logout beacon ONLY when the tab/window is being closed (click was outside the page)
            window.addEventListener('beforeunload', function(e) {
                const nav = performance.getEntriesByType("navigation")[0];
                if (nav && nav.type === "reload") {
                    isInternalNavigation = true;
                }

                if (!isInternalNavigation) {
                    const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
                    const data = new FormData();
                    if (token) data.append('_token', token);
                    if (navigator.sendBeacon) {
                        navigator.sendBeacon('{{ route('logout.beacon') }}', data);
                    }
                }
            });
        })();
    </script>

    <x-ai-copilot />

    @livewireScripts
</body>
</html>
